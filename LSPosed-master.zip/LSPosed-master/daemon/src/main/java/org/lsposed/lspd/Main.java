package org.lsposed.lspd;

import org.lsposed.lspd.service.ServiceManager;

public class Main {

    public static void main(String[] args) {
        ServiceManager.start(args);
    }
}
