package com.android.server;

public abstract class SystemService {
}
