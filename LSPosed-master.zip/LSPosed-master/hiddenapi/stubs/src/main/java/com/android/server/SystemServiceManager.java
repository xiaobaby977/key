package com.android.server;

import java.util.ArrayList;

public class SystemServiceManager {
    private final ArrayList<SystemService> mServices = new ArrayList<>();
}
