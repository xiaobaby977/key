package android.system;

public final class ErrnoException extends Exception {

}
