package android.os;

public class PersistableBundle {
}
