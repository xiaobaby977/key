package android.content.pm;

public class PackageInstaller {
    public static class SessionParams {
        public int installFlags = 0;
    }
}
