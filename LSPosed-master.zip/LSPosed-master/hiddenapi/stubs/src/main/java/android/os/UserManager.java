package android.os;

import android.content.pm.UserInfo;

import java.util.List;

public class UserManager {
    public List<UserInfo> getUsers() {
        throw new UnsupportedOperationException("STUB");
    }
}
