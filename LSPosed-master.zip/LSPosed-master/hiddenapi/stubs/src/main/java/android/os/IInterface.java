package android.os;

public interface IInterface {

    IBinder asBinder();
}
