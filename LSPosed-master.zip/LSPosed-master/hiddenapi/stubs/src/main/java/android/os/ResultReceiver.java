package android.os;

public class ResultReceiver {
}
