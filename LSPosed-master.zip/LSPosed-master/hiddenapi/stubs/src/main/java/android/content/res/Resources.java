package android.content.res;

import android.util.DisplayMetrics;

public class Resources {
	public Resources(AssetManager assets, DisplayMetrics metrics, Configuration config) {
		throw new UnsupportedOperationException("STUB");
	}

	public Resources(ClassLoader classLoader) {
		throw new UnsupportedOperationException("STUB");
	}

	public void setImpl(ResourcesImpl impl) {
		throw new UnsupportedOperationException("STUB");
	}

	public CompatibilityInfo getCompatibilityInfo() {
	    throw new UnsupportedOperationException("STUB");
	}
}
