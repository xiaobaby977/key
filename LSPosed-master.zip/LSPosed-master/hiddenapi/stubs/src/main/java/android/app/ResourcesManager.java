package android.app;

public class ResourcesManager {
}
