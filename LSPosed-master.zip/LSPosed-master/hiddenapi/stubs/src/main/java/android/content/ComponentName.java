package android.content;

public final class ComponentName {
}
