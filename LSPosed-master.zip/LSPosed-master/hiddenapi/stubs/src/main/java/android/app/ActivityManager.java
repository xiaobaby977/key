package android.app;

public class ActivityManager {
    public static int UID_OBSERVER_GONE;
    public static int UID_OBSERVER_ACTIVE;
    public static int UID_OBSERVER_IDLE;
    public static int UID_OBSERVER_CACHED;
    public static int PROCESS_STATE_UNKNOWN;
}
