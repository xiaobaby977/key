package android.os;

public class RemoteException extends Exception {

    public RemoteException(String message) {
        throw new RuntimeException("STUB");
    }
}
