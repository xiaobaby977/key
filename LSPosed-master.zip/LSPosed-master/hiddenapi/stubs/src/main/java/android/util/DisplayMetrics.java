package android.util;

public class DisplayMetrics {
}
