package android.content.res;

public class TypedArray {
	protected TypedArray(Resources resources) {
		throw new UnsupportedOperationException("STUB");
	}
}
